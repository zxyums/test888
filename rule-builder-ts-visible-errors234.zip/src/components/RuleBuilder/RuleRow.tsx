import React from 'react';
import { useFormContext, useWatch } from 'react-hook-form';
import { FieldOption } from './types';

interface RuleRowProps {
  fieldName: string;
  index: number;
  onRemove: () => void;
  fieldOptions: FieldOption[];
}

const operators = ['is', 'is not', 'greater than', 'less than', 'contains'];

const RuleRow: React.FC<RuleRowProps> = ({ fieldName, onRemove, fieldOptions }) => {
  const { register, control, formState: { errors } } = useFormContext();
  const selectedField = useWatch({ name: `${fieldName}.field`, control });
  const fieldMeta = fieldOptions.find(f => f.label === selectedField);

  const getError = (fieldKey: string) => {
    const error = errors?.[fieldName?.split('.')?.[0]]?.[parseInt(fieldName.split('.')[1])]?.[fieldKey];
    return error ? <span style={{ color: 'red', fontSize: '12px' }}>Required</span> : null;
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', marginBottom: 10 }}>
      <div style={{ display: 'flex', gap: 10 }}>
        <div>
          <select {...register(`${fieldName}.logic`, { required: true })}>
            <option value="">--Select--</option>
            <option value="AND">AND</option>
            <option value="OR">OR</option>
          </select>
          {getError('logic')}
        </div>

        <div>
          <select {...register(`${fieldName}.field`, { required: true })}>
            <option value="">--Select Field--</option>
            {fieldOptions.map(opt => (
              <option key={opt.label} value={opt.label}>{opt.label}</option>
            ))}
          </select>
          {getError('field')}
        </div>

        <div>
          <select {...register(`${fieldName}.operator`, { required: true })}>
            <option value="">--Select Operator--</option>
            {operators.map(op => (
              <option key={op} value={op}>{op}</option>
            ))}
          </select>
          {getError('operator')}
        </div>

        <div>
          {fieldMeta?.type === 'select' ? (
            <select {...register(`${fieldName}.value`, { required: true })}>
              <option value="">--Select Value--</option>
              {fieldMeta.values?.map(v => (
                <option key={v} value={v}>{v}</option>
              ))}
            </select>
          ) : (
            <input
              type={fieldMeta?.type || 'text'}
              placeholder={`Enter ${selectedField}`}
              {...register(`${fieldName}.value`, { required: true })}
            />
          )}
          {getError('value')}
        </div>

        <button type="button" onClick={onRemove}>−</button>
      </div>
    </div>
  );
};

export default RuleRow;