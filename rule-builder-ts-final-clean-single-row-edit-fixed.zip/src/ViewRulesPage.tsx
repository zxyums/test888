import React, { useEffect, useState } from 'react';
import RuleBuilder from './components/RuleBuilder/RuleBuilder';
import { RuleFormData } from './components/RuleBuilder/types';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';

const STORAGE_KEY = 'savedRulesList';

const ViewRulesPage: React.FC = () => {
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [rulesList, setRulesList] = useState<RuleFormData[]>([]);
  const [builderKey, setBuilderKey] = useState(0);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        setRulesList(JSON.parse(stored));
      } catch {
        setRulesList([]);
      }
    }
  }, []);

  const handleSave = (data: RuleFormData) => {
    if (!data.groups || data.groups.length === 0 || data.groups[0].rules.length === 0) return;

    const newList = [...rulesList];
    if (editingIndex !== null) {
      newList[editingIndex] = data;
    } else {
      newList.push(data);
    }

    localStorage.setItem(STORAGE_KEY, JSON.stringify(newList));
    setRulesList(newList);
    setEditingIndex(null);
    setBuilderKey(prev => prev + 1);
  };

  const handleEdit = (index: number) => {
    setEditingIndex(index);
    setBuilderKey(prev => prev + 1);
  };

  const generateSummary = (data: RuleFormData): string => {
    return data.groups.map(group =>
      group.rules.map((rule, i) =>
        i === 0
          ? `${rule.field} ${rule.operator} "${rule.value}"`
          : `${rule.logic} ${rule.field} ${rule.operator} "${rule.value}"`
      ).join(' ')
    ).join(' AND ');
  };

  const columnDefs = [
    { headerName: 'Summary', field: 'summary', flex: 1 },
    {
      headerName: 'Actions',
      field: 'actions',
      width: 120,
      cellRenderer: (params: any) => (
        <button onClick={() => handleEdit(params.rowIndex)}>Edit</button>
      )
    }
  ];

  const rowData = rulesList.map((data, i) => ({
    summary: generateSummary(data),
    index: i
  }));

  return (
    <div>
      <h2>Rule Management</h2>
      <RuleBuilder
        key={builderKey}
        initialData={editingIndex !== null ? rulesList[editingIndex] : undefined}
        onSave={handleSave}
      />

      <div className="ag-theme-alpine" style={{ height: 300, marginTop: 30 }}>
        <AgGridReact rowData={rowData} columnDefs={columnDefs} />
      </div>
    </div>
  );
};

export default ViewRulesPage;