import React from 'react';
import { useForm, useFieldArray, FormProvider } from 'react-hook-form';
import { RuleBuilderProps, RuleFormData, FieldOption } from './types';
import RuleSummary from './RuleSummary';

const defaultFieldOptions: FieldOption[] = [
  { label: 'Country', type: 'select', values: ['USA', 'India', 'Germany', 'France'] },
  { label: 'State', type: 'select', values: ['California', 'Texas', 'New York'] },
  { label: 'Age', type: 'number' },
  { label: 'Zip Code', type: 'text' }
];

const RuleBuilder: React.FC<RuleBuilderProps> = ({ fieldOptions = defaultFieldOptions, onSave, initialData }) => {
  const methods = useForm<RuleFormData>({
    mode: 'onChange',
    defaultValues: initialData || {
      groups: [{ groupLogic: 'AND', rules: [{ field: '', operator: '', value: '' }] }]
    }
  });

  const { control, handleSubmit, watch, register, setValue, formState: { isValid } } = methods;
  const { fields: groupFields, append: appendGroup, remove: removeGroup } = useFieldArray({ control, name: 'groups' });

  const onSubmit = (data: RuleFormData) => {
    if (onSave) onSave(data);
  };

  const addConditionToGroup = (groupIndex: number) => {
    const currentRules = watch(`groups.${groupIndex}.rules`) || [];
    const updatedRules = [{ field: '', operator: '', value: '', logic: 'AND' }, ...currentRules];
    setValue(`groups.${groupIndex}.rules`, updatedRules);
  };

  const removeConditionFromGroup = (groupIndex: number, ruleIndex: number) => {
    const currentRules = watch(`groups.${groupIndex}.rules`);
    currentRules.splice(ruleIndex, 1);
    setValue(`groups.${groupIndex}.rules`, [...currentRules]);
  };

  return (
    <FormProvider {...methods}>
      <form onSubmit={handleSubmit(onSubmit)} style={{ padding: 20 }}>
        <h3>Rule Builder</h3>
        {groupFields.map((group, groupIndex) => {
          const groupPath = `groups.${groupIndex}`;
          const rules = watch(`${groupPath}.rules`) || [];

          return (
            <div key={group.id} style={{ border: '1px solid #ccc', marginBottom: 15, padding: 10 }}>
              <h4>Group {groupIndex + 1} — Combine using:
                <select {...register(`${groupPath}.groupLogic`, { required: true })}>
                  <option value="">--Logic--</option>
                  <option value="AND">AND</option>
                  <option value="OR">OR</option>
                </select>
              </h4>

              {rules.map((rule, ruleIndex) => (
                <div key={ruleIndex} style={{ display: 'flex', gap: 10, marginBottom: 5 }}>
                  {ruleIndex > 0 && (
                    <select {...register(`${groupPath}.rules.${ruleIndex}.logic`, { required: true })}>
                      <option value="AND">AND</option>
                      <option value="OR">OR</option>
                    </select>
                  )}
                  <select {...register(`${groupPath}.rules.${ruleIndex}.field`, { required: true })}>
                    <option value="">--Select Field--</option>
                    {fieldOptions.map(f => (
                      <option key={f.label} value={f.label}>{f.label}</option>
                    ))}
                  </select>
                  <select {...register(`${groupPath}.rules.${ruleIndex}.operator`, { required: true })}>
                    <option value="">--Select Operator--</option>
                    <option value="is">is</option>
                    <option value="is not">is not</option>
                    <option value="contains">contains</option>
                    <option value="greater than">greater than</option>
                    <option value="less than">less than</option>
                  </select>
                  <input type="text" {...register(`${groupPath}.rules.${ruleIndex}.value`, { required: true })} placeholder="Enter" />
                  <button type="button" onClick={() => removeConditionFromGroup(groupIndex, ruleIndex)}>−</button>
                </div>
              ))}

              <button type="button" onClick={() => addConditionToGroup(groupIndex)}>+ Add Condition</button>
              <button type="button" onClick={() => removeGroup(groupIndex)} style={{ marginLeft: 10 }}>Delete Group</button>
            </div>
          );
        })}

        <button type="button" onClick={() =>
          appendGroup({ groupLogic: 'AND', rules: [{ field: '', operator: '', value: '' }] })
        }>+ Add Group</button>

        <button type="submit" style={{ marginLeft: 10 }} disabled={!isValid}>Save Rules</button>

        <RuleSummary groups={watch('groups')} />
      </form>
    </FormProvider>
  );
};

export default RuleBuilder;