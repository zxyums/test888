import React, { useEffect, useState } from 'react';
import RuleBuilder from './components/RuleBuilder/RuleBuilder';
import { RuleFormData } from './components/RuleBuilder/types';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-enterprise';
// Add your AG Grid license key setup here
// import { LicenseManager } from 'ag-grid-enterprise';
// LicenseManager.setLicenseKey('YOUR_LICENSE_KEY');
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';

const STORAGE_KEY = 'savedRules';

const ViewRulesPage: React.FC = () => {
  const [editing, setEditing] = useState(false);
  const [expanded, setExpanded] = useState(true);
  const [ruleData, setRuleData] = useState<RuleFormData | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        setRuleData(JSON.parse(saved));
      } catch {
        setRuleData(null);
      }
    }
  }, []);

  const handleSave = (data: RuleFormData) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    setRuleData(data);
    setEditing(false);
  };

  const flattenedRows = ruleData?.groups.flatMap((group, groupIndex) =>
    group.rules.map((rule, ruleIndex) => ({
      group: `Group ${groupIndex + 1}`,
      groupLogic: group.groupLogic,
      ...rule
    }))
  ) || [];

  const columnDefs = [
    { headerName: 'Group', field: 'group' },
    { headerName: 'Group Logic', field: 'groupLogic' },
    { headerName: 'Condition Logic', field: 'logic' },
    { headerName: 'Field', field: 'field' },
    { headerName: 'Operator', field: 'operator' },
    { headerName: 'Value', field: 'value' }
  ];

  return (
    <div style={{ padding: 20 }}>
      <h2>Rule Management</h2>

      {editing && (
        <div style={{ marginBottom: 20 }}>
          <button onClick={() => setExpanded(!expanded)}>
            {expanded ? 'Collapse Rule Builder' : 'Expand Rule Builder'}
          </button>
          {expanded && (
            <div style={{ marginTop: 10 }}>
              <RuleBuilder
                initialData={ruleData || {
                  groups: [{ groupLogic: 'AND', rules: [{ field: '', operator: '', value: '', logic: 'OR' }] }]
                }}
                onSave={handleSave}
              />
            </div>
          )}
        </div>
      )}

      <h3>View Saved Rules</h3>
      <div className="ag-theme-alpine" style={{ height: 300, width: '100%' }}>
        <AgGridReact rowData={flattenedRows} columnDefs={columnDefs} />
      </div>

      {!editing && (
        <div style={{ marginTop: 20 }}>
          <button onClick={() => setEditing(true)} style={{ marginRight: 10 }}>Edit</button>
          <button
            onClick={() => {
              setRuleData(null);
              setEditing(true);
            }}
          >
            + Add New Group
          </button>
        </div>
      )}
    </div>
  );
};

export default ViewRulesPage;