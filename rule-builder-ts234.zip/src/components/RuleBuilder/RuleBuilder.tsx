import React from 'react';
import { useForm, useFieldArray, FormProvider } from 'react-hook-form';
import RuleGroup from './RuleGroup';
import RuleSummary from './RuleSummary';
import { evaluateRules } from './evaluateRules';
import { RuleBuilderProps, RuleFormData } from './types';

const RuleBuilder: React.FC<RuleBuilderProps> = ({ fieldOptions, onSave }) => {
  const methods = useForm<RuleFormData>({
    mode: 'onChange',
    defaultValues: {
      groups: [
        {
          groupLogic: 'AND',
          rules: [{ field: fieldOptions?.[0]?.label || 'State', operator: 'is', value: '', logic: 'OR' }]
        }
      ],
      page: 1
    }
  });

  const {
    control,
    handleSubmit,
    watch,
    formState: { isValid }
  } = methods;

  const {
    fields: groupFields,
    append: appendGroup,
    remove: removeGroup
  } = useFieldArray({ control, name: 'groups' });

  const onSubmit = (data: RuleFormData) => {
    const result = evaluateRules(data.groups, data.testInput || {});
    const payload = { ...data, match: result };
    if (onSave) onSave(payload);
  };

  return (
    <FormProvider {...methods}>
      <form onSubmit={handleSubmit(onSubmit)} style={{ padding: 20 }}>
        <h2>Rule Builder</h2>
        {groupFields.map((group, groupIndex) => (
          <RuleGroup
            key={group.id}
            groupIndex={groupIndex}
            onRemoveGroup={() => removeGroup(groupIndex)}
            fieldOptions={fieldOptions || []}
          />
        ))}
        <button type="button" onClick={() => appendGroup({
          groupLogic: 'AND',
          rules: [{ field: fieldOptions?.[0]?.label || 'State', operator: 'is', value: '', logic: 'OR' }]
        })}>
          + Add Group
        </button>
        <div style={{ marginTop: 20 }}>
          Skip to Page:
          <input type="number" {...methods.register('page')} />
        </div>
        <button type="submit" disabled={!isValid} style={{ marginTop: 20 }}>
          Save Rules
        </button>
        <RuleSummary groups={watch('groups')} page={watch('page')} />
      </form>
    </FormProvider>
  );
};

export default RuleBuilder;