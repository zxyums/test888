export type FieldType = 'select' | 'text' | 'number';

export interface FieldOption {
  label: string;
  type: FieldType;
  values?: string[];
}

export interface Rule {
  field: string;
  operator: string;
  value: string;
  logic: 'AND' | 'OR';
}

export interface RuleGroup {
  groupLogic: 'AND' | 'OR';
  rules: Rule[];
}

export interface RuleFormData {
  groups: RuleGroup[];
  page: number;
  testInput?: Record<string, any>;
}

export interface RuleBuilderProps {
  fieldOptions?: FieldOption[];
  onSave?: (data: RuleFormData & { match: boolean }) => void;
}