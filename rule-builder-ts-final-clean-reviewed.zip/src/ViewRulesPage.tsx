import React, { useEffect, useState } from 'react';
import RuleBuilder from './components/RuleBuilder/RuleBuilder';
import { RuleFormData } from './components/RuleBuilder/types';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';

const STORAGE_KEY = 'savedRules';

const ViewRulesPage: React.FC = () => {
  const [editing, setEditing] = useState(true);
  const [ruleData, setRuleData] = useState<RuleFormData | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        setRuleData(JSON.parse(saved));
      } catch {
        setRuleData(null);
      }
    }
  }, []);

  const handleSave = (data: RuleFormData) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    setRuleData(data);
    setEditing(false);
  };

  const flattenedRows = ruleData?.groups.flatMap((group, groupIndex) =>
    group.rules.map((rule, ruleIndex) => ({
      group: `Group ${groupIndex + 1}`,
      groupLogic: group.groupLogic,
      logic: ruleIndex === 0 ? '' : rule.logic || '',
      ...rule
    }))
  ) || [];

  const columnDefs = [
    { headerName: 'Group', field: 'group' },
    { headerName: 'Group Logic', field: 'groupLogic' },
    { headerName: 'Condition Logic', field: 'logic' },
    { headerName: 'Field', field: 'field' },
    { headerName: 'Operator', field: 'operator' },
    { headerName: 'Value', field: 'value' }
  ];

  return (
    <div>
      <h2>Rule Management</h2>
      {editing && (
        <RuleBuilder
          initialData={ruleData || undefined}
          onSave={handleSave}
        />
      )}

      <div className="ag-theme-alpine" style={{ height: 300, width: '100%', marginTop: 30 }}>
        <AgGridReact rowData={flattenedRows} columnDefs={columnDefs} />
      </div>

      {!editing && (
        <div style={{ marginTop: 10 }}>
          <button onClick={() => setEditing(true)}>Edit</button>
        </div>
      )}
    </div>
  );
};

export default ViewRulesPage;