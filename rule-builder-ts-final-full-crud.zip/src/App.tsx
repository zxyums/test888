import React from 'react';
import ViewRulesPage from './ViewRulesPage';

const App: React.FC = () => {
  return <ViewRulesPage />;
};

export default App;