import React, { useState } from 'react';
import RuleBuilder from './components/RuleBuilder/RuleBuilder';
import { RuleFormData } from './components/RuleBuilder/types';

const ViewRulesPage: React.FC = () => {
  const [editing, setEditing] = useState(false);

  const mockRuleData: RuleFormData = {
    groups: [
      {
        groupLogic: 'AND',
        rules: [
          { field: 'Country', operator: 'is', value: 'USA', logic: 'AND' },
          { field: 'State', operator: 'is not', value: 'California', logic: 'OR' }
        ]
      },
      {
        groupLogic: 'OR',
        rules: [
          { field: 'Zip Code', operator: 'contains', value: '90', logic: 'AND' },
          { field: 'Age', operator: 'greater than', value: '25', logic: 'OR' }
        ]
      }
    ]
  };

  return (
    <div style={{ marginTop: 50 }}>
      {!editing ? (
        <>
          <h2>View Saved Rules</h2>
          <pre style={{ background: '#f8f8f8', padding: 10 }}>
            {JSON.stringify(mockRuleData, null, 2)}
          </pre>
          <button onClick={() => setEditing(true)}>Edit</button>
        </>
      ) : (
        <>
          <h2>Edit Rules</h2>
          <RuleBuilder initialData={mockRuleData} />
        </>
      )}
    </div>
  );
};

export default ViewRulesPage;