import React from 'react';
import ViewRulesPage from './ViewRulesPage';

const App: React.FC = () => <ViewRulesPage />;
export default App;