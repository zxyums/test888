import React, { useEffect, useState } from 'react';
import RuleBuilder from './components/RuleBuilder/RuleBuilder';
import { RuleFormData } from './components/RuleBuilder/types';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';

const STORAGE_KEY = 'savedRulesList';

const ViewRulesPage: React.FC = () => {
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [rulesList, setRulesList] = useState<RuleFormData[]>([]);
  const [builderKey, setBuilderKey] = useState(0); // force rerender on edit

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        setRulesList(JSON.parse(stored));
      } catch {
        setRulesList([]);
      }
    }
  }, []);

  const handleSave = (data: RuleFormData) => {
    const updated = [...rulesList];
    if (editingIndex !== null) {
      updated[editingIndex] = data;
    } else {
      updated.push(data);
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    setRulesList(updated);
    setEditingIndex(null);
    setBuilderKey(prev => prev + 1); // reset builder
  };

  const handleEdit = (index: number) => {
    setEditingIndex(index);
    setBuilderKey(prev => prev + 1);
  };

  const columnDefs = [
    { headerName: 'Total Groups', field: 'groupCount', width: 120 },
    { headerName: 'Total Rules', field: 'ruleCount', width: 120 },
    { headerName: 'Actions', field: 'actions', cellRenderer: (params: any) => (
      <button onClick={() => handleEdit(params.rowIndex)}>Edit</button>
    )}
  ];

  const rowData = rulesList.map((r, idx) => ({
    groupCount: r.groups.length,
    ruleCount: r.groups.reduce((acc, g) => acc + g.rules.length, 0)
  }));

  return (
    <div>
      <h2>Rule Management</h2>
      <RuleBuilder
        key={builderKey}
        initialData={editingIndex !== null ? rulesList[editingIndex] : undefined}
        onSave={handleSave}
      />

      <div className="ag-theme-alpine" style={{ height: 250, marginTop: 30 }}>
        <AgGridReact rowData={rowData} columnDefs={columnDefs} domLayout="autoHeight" />
      </div>
    </div>
  );
};

export default ViewRulesPage;