import React from 'react';
import { RuleGroup } from './types';

interface Props {
  groups: RuleGroup[];
  renderOnlyText?: boolean;
}

const RuleSummary: React.FC<Props> = ({ groups, renderOnlyText = false }) => {
  if (!groups || groups.length === 0) return renderOnlyText ? '' : <div style={{ marginTop: 20 }}>No rules defined</div>;

  const groupDescriptions = groups.map((group) => {
    const ruleTexts = group.rules.map((rule, i) =>
      i === 0
        ? `${rule.field} ${rule.operator} "${rule.value}"`
        : `${rule.logic} ${rule.field} ${rule.operator} "${rule.value}"`
    ).join(' ');

    return `(${ruleTexts})`;
  });

  const summaryText = groupDescriptions.join(' AND ');

  return renderOnlyText
    ? summaryText
    : (
      <div style={{ background: '#f1f1f1', padding: 12, marginTop: 20, borderRadius: 6 }}>
        <h3>Summary</h3>
        <p>{summaryText}</p>
      </div>
    );
};

export default RuleSummary;