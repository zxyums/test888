import React from 'react';
import { RuleGroup } from './types';

interface Props {
  groups: RuleGroup[];
}

const RuleSummary: React.FC<Props> = ({ groups }) => {
  const groupDescriptions = groups.map((group) => {
    const ruleTexts = group.rules.map(rule => (
      \`\${rule.field} \${rule.operator} "\${rule.value}"\`
    )).join(\` \${group.rules[0]?.logic || 'OR'} \`);
    return \`(\${ruleTexts})\`;
  });

  return (
    <div style={{ background: '#f1f1f1', padding: 12, marginTop: 20, borderRadius: 6 }}>
      <h3>Summary</h3>
      <p>
        If {groupDescriptions.join(' AND ')}
      </p>
    </div>
  );
};

export default RuleSummary;