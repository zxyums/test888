import React, { useEffect, useState } from 'react';

interface Rule {
  field: string;
  operator: string;
  value: string;
}

const fieldOptions = ['account_count_change', 'subject_role', 'subject_status'];
const operatorOptions = ['is', 'is not', 'contains', 'empty'];

const SimpleRuleBuilder: React.FC = () => {
  const [field, setField] = useState('');
  const [operator, setOperator] = useState('');
  const [value, setValue] = useState('');
  const [rules, setRules] = useState<Rule[]>([]);
  const [editIndex, setEditIndex] = useState<number | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem('simpleRules');
    if (stored) {
      setRules(JSON.parse(stored));
    }
  }, []);

  const resetForm = () => {
    setField('');
    setOperator('');
    setValue('');
    setEditIndex(null);
  };

  const handleAddOrUpdate = () => {
    if (!field || !operator || (operator !== 'empty' && !value)) return;

    const newRule = { field, operator, value };
    const updatedRules = [...rules];

    if (editIndex !== null) {
      updatedRules[editIndex] = newRule;
    } else {
      updatedRules.push(newRule);
    }

    setRules(updatedRules);
    localStorage.setItem('simpleRules', JSON.stringify(updatedRules));
    resetForm();
  };

  const handleEdit = (index: number) => {
    const rule = rules[index];
    setField(rule.field);
    setOperator(rule.operator);
    setValue(rule.value);
    setEditIndex(index);
  };

  const handleDelete = (index: number) => {
    const updated = rules.filter((_, i) => i !== index);
    setRules(updated);
    localStorage.setItem('simpleRules', JSON.stringify(updated));
    resetForm();
  };

  return (
    <div style={{ padding: 20 }}>
      <h3>Data Source Condition</h3>
      <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 10 }}>
        <label>the data source field</label>
        <select value={field} onChange={e => setField(e.target.value)}>
          <option value="">Select Field</option>
          {fieldOptions.map(f => <option key={f} value={f}>{f}</option>)}
        </select>
        <select value={operator} onChange={e => setOperator(e.target.value)}>
          <option value="">Select Operator</option>
          {operatorOptions.map(o => <option key={o} value={o}>{o}</option>)}
        </select>
        {operator !== 'empty' && (
          <input
            type="text"
            placeholder="Enter value"
            value={value}
            onChange={e => setValue(e.target.value)}
          />
        )}
        <button onClick={handleAddOrUpdate}>OK</button>
      </div>

      <div>
        <h4>List of Conditions</h4>
        {rules.length === 0 && <p>No rules added yet.</p>}
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {rules.map((r, index) => (
            <li key={index} style={{ background: '#eee', marginBottom: 8, padding: 8, borderRadius: 4 }}>
              <span>{`${r.field} ${r.operator}${r.operator !== 'empty' ? ' ' + r.value : ''}`}</span>
              <button onClick={() => handleEdit(index)} style={{ marginLeft: 10 }}>Edit</button>
              <button onClick={() => handleDelete(index)} style={{ marginLeft: 5 }}>Remove</button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default SimpleRuleBuilder;