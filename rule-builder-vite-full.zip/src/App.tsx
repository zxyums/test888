import React from 'react';
import SimpleRuleBuilder from './SimpleRuleBuilder';

const App: React.FC = () => {
  return (
    <div>
      <SimpleRuleBuilder />
    </div>
  );
};

export default App;