import React from 'react';
import { useFormContext, useFieldArray } from 'react-hook-form';
import RuleRow from './RuleRow';
import { FieldOption } from './types';

interface Props {
  groupIndex: number;
  onRemoveGroup: () => void;
  fieldOptions: FieldOption[];
}

const RuleGroup: React.FC<Props> = ({ groupIndex, onRemoveGroup, fieldOptions }) => {
  const { control, register } = useFormContext();
  const rulesField = `groups.${groupIndex}.rules`;
  const { fields, append, remove } = useFieldArray({ control, name: rulesField });

  return (
    <div style={{ border: '1px solid #ccc', padding: 10, marginBottom: 20 }}>
      <h4>
        Group {groupIndex + 1} — Combine using:
        <select {...register(`groups.${groupIndex}.groupLogic`)}>
          <option value="AND">AND</option>
          <option value="OR">OR</option>
        </select>
      </h4>
      {fields.map((field, ruleIndex) => (
        <RuleRow
          key={field.id}
          fieldName={`${rulesField}.${ruleIndex}`}
          index={ruleIndex}
          onRemove={() => remove(ruleIndex)}
          fieldOptions={fieldOptions}
        />
      ))}
      <button type="button" onClick={() => append({
        field: fieldOptions[0].label,
        operator: 'is',
        value: '',
        logic: 'OR'
      })}>
        + Add Condition
      </button>
      <button type="button" onClick={onRemoveGroup} style={{ marginLeft: 10 }}>
        Delete Group
      </button>
    </div>
  );
};

export default RuleGroup;