import React from 'react';
import { useForm, useFieldArray, FormProvider } from 'react-hook-form';
import RuleGroup from './RuleGroup';
import { evaluateRules } from './evaluateRules';
import { RuleBuilderProps, RuleFormData, FieldOption } from './types';

const defaultFieldOptions: FieldOption[] = [
  { label: 'Country', type: 'select', values: ['USA', 'India', 'Germany', 'France'] },
  { label: 'State', type: 'select', values: ['California', 'Texas', 'New York'] },
  { label: 'Age', type: 'number' },
  { label: 'Zip Code', type: 'text' }
];

const RuleBuilder: React.FC<RuleBuilderProps> = ({ fieldOptions = defaultFieldOptions, onSave }) => {
  const methods = useForm<RuleFormData>({
    mode: 'onChange',
    defaultValues: {
      groups: [
        {
          groupLogic: 'AND',
          rules: [{ field: fieldOptions[0].label, operator: 'is', value: '', logic: 'OR' }]
        }
      ]
    }
  });

  const {
    control,
    handleSubmit,
    watch,
    formState: { isValid }
  } = methods;

  const {
    fields: groupFields,
    append: appendGroup,
    remove: removeGroup
  } = useFieldArray({ control, name: 'groups' });

  const onSubmit = (data: RuleFormData) => {
    const result = evaluateRules(data.groups, data.testInput || {});
    const payload = { ...data, match: result };
    if (onSave) onSave(payload);
  };

  return (
    <FormProvider {...methods}>
      <form onSubmit={handleSubmit(onSubmit)} style={{ padding: 20 }}>
        <h2>Rule Builder</h2>
        {groupFields.map((group, groupIndex) => (
          <RuleGroup
            key={group.id}
            groupIndex={groupIndex}
            onRemoveGroup={() => removeGroup(groupIndex)}
            fieldOptions={fieldOptions}
          />
        ))}
        <button type="button" onClick={() => appendGroup({
          groupLogic: 'AND',
          rules: [{ field: fieldOptions[0].label, operator: 'is', value: '', logic: 'OR' }]
        })}>
          + Add Group
        </button>
        <button type="submit" disabled={!isValid} style={{ marginTop: 20 }}>
          Save Rules
        </button>
      </form>
    </FormProvider>
  );
};

export default RuleBuilder;