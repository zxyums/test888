import React from 'react';
import { RuleGroup } from './types';

interface Props {
  groups: RuleGroup[];
}

const RuleSummary: React.FC<Props> = ({ groups }) => {
  if (!groups || groups.length === 0) return <div style={{ marginTop: 20 }}>No rules defined</div>;

  const groupDescriptions = groups.map((group) => {
    if (!group.rules || group.rules.length === 0) return "";

    const ruleTexts = group.rules.map((rule, i) =>
      i > 0 && rule.logic ? `${rule.logic} ${rule.field} ${rule.operator} "${rule.value}"` :
      `${rule.field} ${rule.operator} "${rule.value}"`
    ).join(" ");

    return `(${ruleTexts})`;
  }).filter(Boolean);

  return (
    <div style={{ background: '#f1f1f1', padding: 12, marginTop: 20, borderRadius: 6 }}>
      <h3>Summary</h3>
      <p>{groupDescriptions.join(" AND ")}</p>
    </div>
  );
};

export default RuleSummary;