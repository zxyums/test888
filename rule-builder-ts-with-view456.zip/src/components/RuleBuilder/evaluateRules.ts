import { RuleGroup } from './types';

export const evaluateRules = (groups: RuleGroup[], userInput: Record<string, any>): boolean => {
  const evaluateCondition = (rule: any) => {
    const inputValue = userInput[rule.field];
    const compareValue = rule.value;

    switch (rule.operator) {
      case 'is': return inputValue === compareValue;
      case 'is not': return inputValue !== compareValue;
      case 'contains': return inputValue?.toString().includes(compareValue);
      case 'greater than': return parseFloat(inputValue) > parseFloat(compareValue);
      case 'less than': return parseFloat(inputValue) < parseFloat(compareValue);
      default: return false;
    }
  };

  const evaluateGroup = (group: RuleGroup): boolean => {
    return group.rules.reduce<boolean>((acc, rule, index) => {
      const result = evaluateCondition(rule);
      if (index === 0) return result;
      return rule.logic === 'AND' ? acc && result : acc || result;
    }, false);
  };

  return groups.reduce<boolean>((acc, group, index) => {
    const result = evaluateGroup(group);
    if (index === 0) return result;
    return group.groupLogic === 'AND' ? acc && result : acc || result;
  }, false);
};