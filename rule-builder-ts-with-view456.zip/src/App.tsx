import React from 'react';
import RuleBuilder from './components/RuleBuilder/RuleBuilder';
import { RuleFormData } from './components/RuleBuilder/types';

const App: React.FC = () => {
  const initialData: RuleFormData = {
    groups: [
      {
        groupLogic: 'AND',
        rules: [
          { field: 'Country', operator: 'is', value: 'USA', logic: 'AND' },
          { field: 'State', operator: 'is', value: 'California', logic: 'OR' }
        ]
      }
    ]
  };

  return <RuleBuilder initialData={initialData} />;
};

export default App;