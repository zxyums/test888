import React from 'react';
import { RuleGroup } from './types';

interface Props {
  groups: RuleGroup[];
  page: number;
}

const RuleSummary: React.FC<Props> = ({ groups, page }) => {
  const groupDescriptions = groups.map((group) => {
    const ruleTexts = group.rules.map(rule => (
      `${rule.field} ${rule.operator} "${rule.value}"`
    )).join(` ${group.rules[0]?.logic || 'OR'} `);
    return `(${ruleTexts})`;
  });

  return (
    <div style={{ background: '#f9f9f9', padding: 15, marginTop: 20, borderRadius: 6 }}>
      <h3>Summary</h3>
      <p>
        If {groupDescriptions.join(' AND ')} then <strong>skip to Page {page}</strong>.
      </p>
    </div>
  );
};

export default RuleSummary;