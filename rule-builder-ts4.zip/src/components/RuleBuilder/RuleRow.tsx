import React from 'react';
import { useFormContext, useWatch } from 'react-hook-form';
import { FieldOption } from './types';

interface RuleRowProps {
  fieldName: string;
  index: number;
  onRemove: () => void;
  fieldOptions: FieldOption[];
}

const operators = ['is', 'is not', 'greater than', 'less than', 'contains'];

const RuleRow: React.FC<RuleRowProps> = ({ fieldName, onRemove, fieldOptions }) => {
  const { register, control } = useFormContext();
  const selectedField = useWatch({ name: `${fieldName}.field`, control });
  const fieldMeta = fieldOptions.find(f => f.label === selectedField);

  return (
    <div style={{ display: 'flex', gap: 10, marginBottom: 10 }}>
      <select {...register(`${fieldName}.logic`)}>
        <option value="AND">AND</option>
        <option value="OR">OR</option>
      </select>
      <select {...register(`${fieldName}.field`)}>
        {fieldOptions.map(opt => (
          <option key={opt.label} value={opt.label}>{opt.label}</option>
        ))}
      </select>
      <select {...register(`${fieldName}.operator`)}>
        {operators.map(op => (
          <option key={op} value={op}>{op}</option>
        ))}
      </select>
      {fieldMeta?.type === 'select' ? (
        <select {...register(`${fieldName}.value`)}>
          <option value="">--Select--</option>
          {fieldMeta.values?.map(v => (
            <option key={v} value={v}>{v}</option>
          ))}
        </select>
      ) : (
        <input
          type={fieldMeta?.type || 'text'}
          placeholder={`Enter ${selectedField}`}
          {...register(`${fieldName}.value`)}
        />
      )}
      <button type="button" onClick={onRemove}>−</button>
    </div>
  );
};

export default RuleRow;